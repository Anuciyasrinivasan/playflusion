// script.js
// Config
const API_BASE = 'http://localhost:4000/api'; // change if your backend runs elsewhere

// UI helpers
const qs = s => document.querySelector(s);
const qsa = s => Array.from(document.querySelectorAll(s));
const show = el => el.classList.remove('hidden');
const hide = el => el.classList.add('hidden');

// Tab handling
qsa('.tab-btn').forEach(btn => btn.addEventListener('click', () => {
  qsa('.tab-btn').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
  const game = btn.dataset.game;
  qsa('.game').forEach(g => g.classList.add('hidden'));
  show(qs('#' + game));
}));

// Leaderboard UI
const leaderboardList = qs('#leaderboardList');
const leaderboardGame = qs('#leaderboardGame');
async function loadLeaderboard(game){
  leaderboardList.innerHTML = '<li>Loading...</li>';
  try {
    const res = await fetch(`${API_BASE}/scores?game=${encodeURIComponent(game)}`);
    const json = await res.json();
    if (!json.ok) throw new Error(json.error || 'failed');
    if (!json.scores.length) leaderboardList.innerHTML = '<li>No scores yet</li>';
    else {
      leaderboardList.innerHTML = '';
      json.scores.forEach((s,i) => {
        const li = document.createElement('li');
        li.innerHTML = `<span>${i+1}. ${escapeHtml(s.player)}</span><strong>${s.score}</strong>`;
        leaderboardList.appendChild(li);
      });
    }
  } catch (err) {
    leaderboardList.innerHTML = `<li>Error loading leaderboard</li>`;
    console.error(err);
  }
}
leaderboardGame.addEventListener('change', () => loadLeaderboard(leaderboardGame.value));
qs('#leaderboardBtn').addEventListener('click', () => {
  loadLeaderboard(leaderboardGame.value);
  qs('#leaderboardList').scrollIntoView({behavior:'smooth'});
});
loadLeaderboard(leaderboardGame.value);

// Save modal logic
const saveModal = qs('#saveModal');
const saveMessage = qs('#saveMessage');
const playerNameInput = qs('#playerName');
const saveConfirm = qs('#saveConfirm');
const saveCancel = qs('#saveCancel');

let pendingSave = null; // { game, score }
function openSaveModal(msg, game, score){
  saveMessage.textContent = msg;
  pendingSave = { game, score };
  playerNameInput.value = '';
  show(saveModal);
}
saveCancel.addEventListener('click', ()=> hide(saveModal));
saveConfirm.addEventListener('click', async ()=>{
  const player = playerNameInput.value.trim() || 'Anonymous';
  if (!pendingSave) return hide(saveModal);
  try {
    const res = await fetch(`${API_BASE}/score`, {
      method: 'POST',
      headers: {'content-type':'application/json'},
      body: JSON.stringify({ player, game: pendingSave.game, score: pendingSave.score })
    });
    const json = await res.json();
    if (!json.ok) throw new Error(json.error || 'save failed');
    hide(saveModal);
    loadLeaderboard(leaderboardGame.value);
    alert('Saved! Check leaderboard.');
  } catch (err) {
    alert('Could not save score.');
    console.error(err);
  }
});

// ----------------- Game 1: Tic-Tac-Toe -----------------
const tttBoardEl = qs('#tttBoard');
const tttInfo = qs('#tttInfo');
const tttReset = qs('#tttReset');
const tttSave = qs('#tttSave');

let tttState = Array(9).fill(null);
let tttTurn = 'X';
let tttOver = false;

function renderTic(){
  tttBoardEl.innerHTML = '';
  tttState.forEach((cell,i)=>{
    const d = document.createElement('div');
    d.className = 'ttt-cell';
    d.dataset.i = i;
    d.textContent = tttState[i] || '';
    d.addEventListener('click', () => {
      if (tttOver || tttState[i]) return;
      tttState[i] = tttTurn;
      tttTurn = tttTurn === 'X' ? 'O' : 'X';
      checkTic();
      renderTic();
    });
    tttBoardEl.appendChild(d);
  });
  tttInfo.textContent = tttOver ? 'Game over.' : `Turn: ${tttTurn}`;
}
function checkTic(){
  const wins = [
    [0,1,2],[3,4,5],[6,7,8],
    [0,3,6],[1,4,7],[2,5,8],
    [0,4,8],[2,4,6]
  ];
  for (const w of wins){
    const [a,b,c] = w;
    if (tttState[a] && tttState[a] === tttState[b] && tttState[a] === tttState[c]){
      tttOver = true;
      tttInfo.textContent = `${tttState[a]} wins!`;
      return;
    }
  }
  if (!tttState.includes(null)){ tttOver = true; tttInfo.textContent = 'Draw!'; }
}
tttReset.addEventListener('click', ()=> {
  tttState = Array(9).fill(null); tttTurn = 'X'; tttOver = false; renderTic();
});
tttSave.addEventListener('click', ()=>{
  const score = calculateTicScore();
  openSaveModal(`Save Tic-Tac-Toe score: ${score}`, 'tictactoe', score);
});
// scoring: winner 100, draw 50, ongoing 10 + number of marks
function calculateTicScore(){
  if (!tttOver) return 10 + tttState.filter(Boolean).length;
  if (tttInfo.textContent.includes('wins')) return 100;
  return 50;
}
renderTic();

// ----------------- Game 2: Rock-Paper-Scissors -----------------
const rpsInfo = qs('#rpsInfo');
const rpsButtons = qsa('#rps button[data-move]');
const rpsSave = qs('#rpsSave');
let rpsScore = 0; // player wins count

function botMove(){
  const choices = ['rock','paper','scissors'];
  return choices[Math.floor(Math.random()*3)];
}
function decideRPS(player, bot){
  if (player === bot) return 'draw';
  if ((player==='rock'&&bot==='scissors') || (player==='paper'&&bot==='rock') || (player==='scissors'&&bot==='paper')) return 'win';
  return 'lose';
}
rpsButtons.forEach(b => b.addEventListener('click', e => {
  const player = b.dataset.move;
  const bot = botMove();
  const result = decideRPS(player, bot);
  if (result === 'win') rpsScore += 1;
  else if (result === 'lose') rpsScore = Math.max(0, rpsScore - 1);
  rpsInfo.textContent = `You: ${player} — Bot: ${bot} → ${result.toUpperCase()} | Score: ${rpsScore}`;
}));
rpsSave.addEventListener('click', ()=> {
  openSaveModal(`Save RPS score: ${rpsScore}`, 'rps', rpsScore);
});

// ----------------- Game 3: Memory Match -----------------
const memGrid = qs('#memGrid');
const memInfo = qs('#memInfo');
const memReset = qs('#memReset');
const memSave = qs('#memSave');

let memCards = [];
let memRevealed = [];
let memMatchedCount = 0;
let memTries = 0;

function makeMemoryDeck(){
  const icons = ['🍎','🍌','🍇','🍓','🍒','🍋','🥝','🍍']; // 8 pairs -> 16
  const deck = [...icons, ...icons].map((v,i)=>({id:i, val:v, flipped:false, matched:false}));
  // shuffle
  for (let i=deck.length-1;i>0;i--){
    const j = Math.floor(Math.random()*(i+1));
    [deck[i],deck[j]] = [deck[j],deck[i]];
  }
  return deck;
}
function renderMemory(){
  memGrid.innerHTML = '';
  memCards.forEach((c, idx) => {
    const d = document.createElement('div');
    d.className = 'mem-card';
    d.dataset.idx = idx;
    d.textContent = c.flipped || c.matched ? c.val : '';
    d.style.opacity = c.matched ? 0.8 : 1;
    d.addEventListener('click', () => {
      if (c.flipped || c.matched || memRevealed.length>=2) return;
      c.flipped = true;
      memRevealed.push({card: c, idx});
      if (memRevealed.length === 2) checkMemoryPair();
      renderMemory();
    });
    memGrid.appendChild(d);
  });
  memInfo.textContent = `Tries: ${memTries} — Matched: ${memMatchedCount}/${memCards.length/2}`;
}
function checkMemoryPair(){
  memTries++;
  const [a,b] = memRevealed;
  if (a.card.val === b.card.val){
    a.card.matched = b.card.matched = true;
    memMatchedCount++;
    memRevealed = [];
    if (memMatchedCount === memCards.length/2) {
      memInfo.textContent = `You won in ${memTries} tries!`;
    }
  } else {
    setTimeout(()=>{
      a.card.flipped = b.card.flipped = false;
      memRevealed = [];
      renderMemory();
    }, 700);
  }
}
memReset.addEventListener('click', ()=> {
  memCards = makeMemoryDeck(); memRevealed=[]; memMatchedCount=0; memTries=0; renderMemory();
});
memSave.addEventListener('click', ()=> {
  // scoring: fewer tries -> higher score
  const score = memMatchedCount===memCards.length/2 ? Math.max(100 - memTries, 10) : Math.max(10, 50 - memTries);
  openSaveModal(`Save Memory score: ${score}`, 'memory', score);
});
memCards = makeMemoryDeck();
renderMemory();

// ----------------- small utility: escapeHtml -----------------
function escapeHtml(s){ return (s+'').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }

// ----------------- Game 4: Snake -----------------
const snakeCanvas = qs('#snakeCanvas');
const snakeInfo = qs('#snakeInfo');
const snakeReset = qs('#snakeReset');
const snakeSave = qs('#snakeSave');

let snakeCtx, S_WIDTH, S_HEIGHT, CELL, rows, cols;
let snake = [], dir = {x:1,y:0}, food = null, snakeInterval = null;
let snakeAlive = false, snakeScore = 0, highLen = 0;

function initSnakeCanvas(){
  if (!snakeCanvas) return;
  snakeCtx = snakeCanvas.getContext('2d');
  // logical size (grid)
  S_WIDTH = 420; S_HEIGHT = 420;
  CELL = 20; // 21x21 grid
  cols = Math.floor(S_WIDTH / CELL);
  rows = Math.floor(S_HEIGHT / CELL);
  snakeCanvas.width = cols * CELL;
  snakeCanvas.height = rows * CELL;
  snakeCanvas.style.width = '100%';
  resetSnake();
}
function resetSnake(){
  snake = [{x: Math.floor(cols/2), y: Math.floor(rows/2)}];
  dir = {x:1,y:0};
  placeFood();
  snakeAlive = true;
  snakeScore = 0;
  renderSnake();
  if (snakeInterval) clearInterval(snakeInterval);
  snakeInterval = setInterval(tickSnake, 120); // speed
}
function placeFood(){
  while (true){
    const p = {x: Math.floor(Math.random()*cols), y: Math.floor(Math.random()*rows)};
    if (!snake.some(s => s.x===p.x && s.y===p.y)){ food = p; break; }
  }
}
function tickSnake(){
  if (!snakeAlive) return;
  const head = { x: snake[0].x + dir.x, y: snake[0].y + dir.y };
  // wrap-around
  if (head.x < 0) head.x = cols - 1;
  if (head.y < 0) head.y = rows - 1;
  if (head.x >= cols) head.x = 0;
  if (head.y >= rows) head.y = 0;
  // collision with body?
  if (snake.some((s,i) => i!==0 && s.x===head.x && s.y===head.y)){
    snakeAlive = false;
    clearInterval(snakeInterval);
    snakeInfo.textContent = `Game over. Final length: ${snake.length} — Score: ${snakeScore}`;
    highLen = Math.max(highLen, snake.length);
    return;
  }
  // move
  snake.unshift(head);
  // eat?
  if (food && head.x===food.x && head.y===food.y){
    snakeScore += 10;
    placeFood();
  } else {
    snake.pop();
  }
  renderSnake();
}
function renderSnake(){
  // clear
  snakeCtx.clearRect(0,0,snakeCanvas.width,snakeCanvas.height);
  // grid background
  snakeCtx.fillStyle = 'rgba(0,0,0,0)';
  snakeCtx.fillRect(0,0,snakeCanvas.width,snakeCanvas.height);
  // draw food
  if (food){
    snakeCtx.fillStyle = '#ff6666';
    snakeCtx.fillRect(food.x*CELL + 2, food.y*CELL + 2, CELL - 4, CELL - 4);
  }
  // draw snake
  for (let i=0;i<snake.length;i++){
    const s = snake[i];
    snakeCtx.fillStyle = i===0 ? '#6ee7b7' : 'rgba(110,231,183,0.7)';
    snakeCtx.fillRect(s.x*CELL + 1, s.y*CELL + 1, CELL - 2, CELL - 2);
  }
  snakeInfo.textContent = `Score: ${snakeScore} — Length: ${snake.length}`;
}
function setDirection(dx,dy){
  // Prevent reversing
  if (dx === -dir.x && dy === -dir.y) return;
  dir = {x:dx,y:dy};
}

// keyboard controls
window.addEventListener('keydown', (e) => {
  if (!snakeAlive) return;
  if (['ArrowUp','w','W'].includes(e.key)) setDirection(0,-1);
  if (['ArrowDown','s','S'].includes(e.key)) setDirection(0,1);
  if (['ArrowLeft','a','A'].includes(e.key)) setDirection(-1,0);
  if (['ArrowRight','d','D'].includes(e.key)) setDirection(1,0);
});

// touch controls (simple)
let touchStart = null;
snakeCanvas && snakeCanvas.addEventListener('pointerdown', (e) => {
  touchStart = {x: e.clientX, y: e.clientY};
});
snakeCanvas && snakeCanvas.addEventListener('pointerup', (e) => {
  if (!touchStart) return;
  const dx = e.clientX - touchStart.x;
  const dy = e.clientY - touchStart.y;
  if (Math.abs(dx) > Math.abs(dy)){
    if (dx > 0) setDirection(1,0); else setDirection(-1,0);
  } else {
    if (dy > 0) setDirection(0,1); else setDirection(0,-1);
  }
  touchStart = null;
});

// reset / save hooks
snakeReset && snakeReset.addEventListener('click', ()=> resetSnake());
snakeSave && snakeSave.addEventListener('click', ()=> {
  const finalScore = snake.length * 10 + snakeScore;
  openSaveModal(`Save Snake score: ${finalScore}`, 'snake', finalScore);
});

// initialize on load
initSnakeCanvas();

// when tab switches to snake, ensure canvas sized/rendered
qsa('.tab-btn').forEach(btn => btn.addEventListener('click', () => {
  if (btn.dataset.game === 'snake') {
    setTimeout(()=> renderSnake(), 80);
  }
}));