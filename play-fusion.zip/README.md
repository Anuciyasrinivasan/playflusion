# Play Fusion

Play Fusion is a single-page web app with multiple mini-games and a Node/Express + MongoDB backend to store leaderboards.

## Included games
- Tic-Tac-Toe
- Rock-Paper-Scissors
- Memory Match
- Snake

## Setup (local)

1. Install Node.js (>=16) and MongoDB (or use MongoDB Atlas).

2. Start MongoDB locally or set `MONGO_URI` in `backend/.env`.

3. Install dependencies and start server:
```bash
cd backend
npm install
# copy .env.example to .env and edit if needed
node app.js
```

4. Open http://localhost:4000 in your browser (frontend is served by Express).

## Notes
- Frontend files are in `/frontend`.
- Backend serves `/frontend` statically and exposes `/api/score` and `/api/scores`.
- Do NOT commit real credentials to version control. Use environment variables.

Enjoy!