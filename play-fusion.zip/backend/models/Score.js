// models/Score.js
const mongoose = require('mongoose');

const scoreSchema = new mongoose.Schema({
  player: { type: String, required: true, trim: true },
  game: { type: String, required: true, trim: true },
  score: { type: Number, required: true },
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Score', scoreSchema);
