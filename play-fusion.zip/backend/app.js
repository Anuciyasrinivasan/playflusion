// app.js
require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');
const Score = require('./models/Score');

const app = express();
const PORT = process.env.PORT || 4000;

app.use(cors());
app.use(bodyParser.json());

// Serve frontend static files
app.use('/', express.static(path.join(__dirname, '..', 'frontend')));

const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/playfusion';
mongoose.connect(MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(()=> console.log('Connected to MongoDB'))
  .catch(err => {
    console.error('Mongo connect error:', err.message);
  });

// Save a score
app.post('/api/score', async (req, res) => {
  try {
    const { player, game, score } = req.body;
    if (!player || !game || typeof score !== 'number') {
      return res.status(400).json({ ok:false, error: 'player, game and numeric score required' });
    }
    const doc = new Score({ player, game, score });
    await doc.save();
    res.json({ ok: true, score: doc });
  } catch (err) {
    console.error(err);
    res.status(500).json({ ok:false, error: 'server error' });
  }
});

// Get top scores for a game (query param ?game=RPS)
app.get('/api/scores', async (req, res) => {
  try {
    const game = req.query.game;
    if (!game) return res.status(400).json({ ok:false, error: 'game query required' });
    const results = await Score.find({ game })
      .sort({ score: -1, createdAt: 1 })
      .limit(20)
      .lean();
    res.json({ ok: true, scores: results });
  } catch (err) {
    console.error(err);
    res.status(500).json({ ok:false, error: 'server error' });
  }
});

app.listen(PORT, () => console.log(`Server listening on ${PORT}`));
