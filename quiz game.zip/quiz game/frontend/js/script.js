const clues = [
    { clue: "I have cities, but no houses; forests, but no trees; and water, but no fish. What am I?", answer: "map" },
    { clue: "What has an eye but cannot see?", answer: "needle" },
    { clue: "What is full of holes but still holds water?", answer: "sponge" },
    { clue: "I speak without a mouth and hear without ears. I have no body, but I come alive with wind. What am I?", answer: "echo" }
];

let currentClueIndex = 0;

const clueDisplay = document.getElementById('current-clue');
const answerInput = document.getElementById('answer-input');
const submitButton = document.getElementById('submit-button');
const messageDisplay = document.getElementById('message');

function displayClue() {
    if (currentClueIndex < clues.length) {
        clueDisplay.textContent = clues[currentClueIndex].clue;
        messageDisplay.textContent = '';
        answerInput.value = '';
    } else {
        clueDisplay.textContent = "Congratulations! You found the treasure!";
        answerInput.style.display = 'none';
        submitButton.style.display = 'none';
        messageDisplay.style.color = '#28a745'; // Green for success
        messageDisplay.textContent = "You've completed the treasure hunt!";
    }
}

function checkAnswer() {
    const userAnswer = answerInput.value.trim().toLowerCase();
    const correctAnswer = clues[currentClueIndex].answer.toLowerCase();

    if (userAnswer === correctAnswer) {
        currentClueIndex++;
        messageDisplay.style.color = '#28a745';
        messageDisplay.textContent = "Correct! Here's your next clue.";
        setTimeout(displayClue, 1500); // Display next clue after a short delay
    } else {
        messageDisplay.style.color = '#dc3545';
        messageDisplay.textContent = "Incorrect answer. Try again!";
    }
}

submitButton.addEventListener('click', checkAnswer);
// Initialize the game
displayClue();